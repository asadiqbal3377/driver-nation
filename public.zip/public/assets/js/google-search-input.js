function initCitySearch() {
    const input = document.getElementById('cityInput');
    const options = {
        types: ['(cities)'],
        componentRestrictions: { country: ['au','pk'] }
    };
    const autocomplete = new google.maps.places.Autocomplete(input, options);

    autocomplete.addListener('place_changed', () => {
        const place = autocomplete.getPlace();
        $(input).val(place.name)
        if (!place.geometry) {
            console.log("No details available for input: '" + place.name + "'");
            return;
        }
        // You can handle the selected city details here
        console.log('Selected city:', place.name);
    });
}
