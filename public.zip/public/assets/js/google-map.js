function initMap() {
    // Create the map
    const map = new google.maps.Map(document.getElementById('map'), {
        zoom: 10,
        center: { lat: 0, lng: 0 }, // Default center; will re-center based on user location
    });

    // Initialize the geocoder
    const geocoder = new google.maps.Geocoder();

    // Try HTML5 geolocation to get the user's current location
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
            (position) => {
                const userLocation = {
                    lat: position.coords.latitude,
                    lng: position.coords.longitude,
                };
                map.setCenter(userLocation);

                // Add a marker at the user's location
                new google.maps.Marker({
                    position: userLocation,
                    map: map,
                    title: 'Your Location',
                });
            },
            () => {
                handleLocationError(true, map.getCenter());
            }
        );
    } else {
        // Browser doesn't support Geolocation
        handleLocationError(false, map.getCenter());
    }

    // Create the search box and link it to the UI element
    const input = document.getElementById('searchInput');
    const autocomplete = new google.maps.places.Autocomplete(input, {
        types: ['(cities)'], // Restrict to city names
        componentRestrictions: { country: ['au','pk'] }
    });
    map.controls[google.maps.ControlPosition.TOP_LEFT].push(input);

    // Bias the Autocomplete results towards the current map's viewport
    map.addListener('bounds_changed', () => {
        autocomplete.setBounds(map.getBounds());
    });

    // Listen for the event fired when the user selects a prediction and retrieve more details for that place
    autocomplete.addListener('place_changed', () => {
        const place = autocomplete.getPlace();

        if (!place.geometry || !place.geometry.location) {
            console.log('Returned place contains no geometry');
            return;
        }

        // If the place has a geometry, then present it on the map
        if (place.geometry.viewport) {
            map.fitBounds(place.geometry.viewport);
        } else {
            map.setCenter(place.geometry.location);
            map.setZoom(17);
        }

        // Add a marker for the selected place
        new google.maps.Marker({
            map: map,
            position: place.geometry.location,
        });

        // Perform reverse geocoding to get the city name
        geocodeLatLng(geocoder, place.geometry.location);
    });
}

function geocodeLatLng(geocoder, latlng) {
    geocoder.geocode({ location: latlng }, (results, status) => {
        if (status === 'OK') {
            if (results[0]) {
                const addressComponents = results[0].address_components;
                for (let i = 0; i < addressComponents.length; i++) {
                    const types = addressComponents[i].types;
                    if (types.includes('locality')) {
                        const city = addressComponents[i].long_name;
                        document.getElementById('cityName').value = city;
                        break;
                    }
                }
            } else {
                window.alert('No results found');
            }
        } else {
            window.alert('Geocoder failed due to: ' + status);
        }
    });
}

function handleLocationError(browserHasGeolocation, pos) {
    const infoWindow = new google.maps.InfoWindow({
        position: pos,
    });
    infoWindow.setContent(
        browserHasGeolocation
            ? 'Error: The Geolocation service failed.'
            : "Error: Your browser doesn't support geolocation."
    );
    infoWindow.open(map);
}
