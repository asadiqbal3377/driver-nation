function check() {

    var checkBox = document.getElementById("checbox");
    var text1 = document.getElementsByClassName("text1");
    var text2 = document.getElementsByClassName("text2");

    for (var i = 0; i < text1.length; i++) {

        if (checkBox.checked == true) {
            text1[i].style.display = "block";
            text2[i].style.display = "none";

        } else if (checkBox.checked == false) {
            text1[i].style.display = "none";
            text2[i].style.display = "block";
        }
    }
}

check();



// image drag and drop function used in add car form
class DragDropArea {
    constructor(containerId, inputName, imageSrc, text, buttonText) {
        this.containerId = containerId;
        this.inputName = inputName;
        this.imageSrc = imageSrc;
        this.text = text;
        this.buttonText = buttonText;
        this.init();
    }

    init() {
        // Create elements for drag area and image preview
        const container = document.querySelector(`.drag-drop-container[data-id="${this.containerId}"]`);
        container.innerHTML = `
          <div class="drag-area mt-3" id="drag-area-${this.containerId}">
              <img class="mb-3" src="${this.imageSrc}" alt="Drag Image">
              <p>${this.text}</p>
              <button class="pcod-content-details-btn lp-content-details-btn" type="button">${this.buttonText}</button>
              <input type="file" name="${this.inputName}" id="file-input-${this.containerId}" multiple hidden >
          </div>
          <div class="image-preview" id="image-preview-${this.containerId}"></div>
      `;

        this.dragArea = container.querySelector(`#drag-area-${this.containerId}`);
        this.fileInput = container.querySelector(`#file-input-${this.containerId}`);
        this.imagePreview = container.querySelector(`#image-preview-${this.containerId}`);

        // Set up event listeners
        this.dragArea.querySelector("button").addEventListener("click", () => this.fileInput.click());
        this.fileInput.addEventListener("change", (event) => this.handleFiles(event.target.files));
        this.dragArea.addEventListener("dragover", (event) => this.handleDragOver(event));
        this.dragArea.addEventListener("dragleave", () => this.handleDragLeave());
        this.dragArea.addEventListener("drop", (event) => this.handleDrop(event));
    }

    handleDragOver(event) {
        event.preventDefault();
        this.dragArea.classList.add("bg-light");
    }

    handleDragLeave() {
        this.dragArea.classList.remove("bg-light");
    }

    handleDrop(event) {
        event.preventDefault();
        this.dragArea.classList.remove("bg-light");
        this.handleFiles(event.dataTransfer.files);
    }

    handleFiles(files) {
        [...files].forEach(file => {
            //if (!file.type.startsWith("image/")) return;
            const reader = new FileReader();


            if (file.type.startsWith("image/")) {
                // Handle image files
                reader.onload = (e) => {
                    const fileElement = document.createElement("div");
                    fileElement.classList.add("position-relative");

                    const img = document.createElement("img");
                    img.src = e.target.result;4
                    fileElement.appendChild(img);

                    const removeBtn = document.createElement("button");
                    removeBtn.classList.add("remove-btn");
                    removeBtn.innerHTML = "&times;";
                    removeBtn.onclick = () => fileElement.remove();
                    fileElement.appendChild(removeBtn);

                    this.imagePreview.appendChild(fileElement);
                };
            } else if (file.type.startsWith("video/")) {
                // Handle video files
                reader.onload = (e) => {
                    const fileElement = document.createElement("div");
                    fileElement.classList.add("position-relative");

                    const video = document.createElement("video");
                    video.src = e.target.result;
                    video.controls = true; // Add playback controls
                    video.muted = true; // Mute autoplay
                    video.loop = true; // Loop video
                    video.style.maxWidth = "100%";
                    fileElement.appendChild(video);

                    const removeBtn = document.createElement("button");
                    removeBtn.classList.add("remove-btn");
                    removeBtn.innerHTML = "&times;";
                    removeBtn.onclick = () => fileElement.remove();
                    fileElement.appendChild(removeBtn);

                    this.imagePreview.appendChild(fileElement);

                };
            }

            reader.readAsDataURL(file);
            console.dir(file)
        });
    }
}

// Initialize multiple drag-and-drop areas with dynamic content
/*
document.querySelectorAll(".drag-drop-container").forEach(container => {
    const containerId = container.getAttribute("data-id");
    const inputName = container.getAttribute("data-name");
    const imageSrc = container.getAttribute("data-image-src");
    const text = container.getAttribute("data-text");
    const buttonText = container.getAttribute("data-button-text");

    new DragDropArea(containerId, inputName, imageSrc, text, buttonText);
});
*/







function addField(button) {
    const container = document.getElementById('social-fields-container');
    const newFieldGroup = document.createElement('div');
    newFieldGroup.className = 'social-filed-group mb-2';

    newFieldGroup.innerHTML = `
      <div class="car-group">
          <select name="social_link[]" class="car-input">
              <option value="facebook">Facebook</option>
              <option value="linkedin">LinkedIn</option>
              <option value="instagram">Instagram</option>
          </select>
      </div>
      <div class="car-group">
          <input type="text" class="car-input" placeholder="Add link here" name="social_handle[]">
      </div>
      <div class="add-btn-group">
          <button type="button" class="remove-link" onclick="removeField(this)">
              &#8722;
          </button>
      </div>
  `;

    container.appendChild(newFieldGroup);
}

function removeField(button) {
    const fieldGroup = button.closest('.social-filed-group');
    fieldGroup.remove();
}

// JavaScript function to handle photographer setting profile image change
// function changeImage(event) {
//     const image = document.getElementById('profileImage');
//     const file = event.target.files[0];
//     if (file) {
//         const reader = new FileReader();
//         reader.onload = function(e) {
//             image.src = e.target.result;
//         };
//         reader.readAsDataURL(file);
//     }
// }
function changeImage(event) {
    const image = document.getElementById('profileImage');
    const file = event.target.files[0];

    if (file) {
        const reader = new FileReader();

        reader.onload = function(e) {
            // Hide the default image and show the new one
            image.src = e.target.result;
            image.style.display = 'block'; // Ensure image is visible after upload
        };

        reader.readAsDataURL(file);
    }
}
