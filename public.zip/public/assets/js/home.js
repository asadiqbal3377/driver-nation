jQuery(document).ready(function($) {
    $(".wdn-right-slider-secondary-div").slick({
        dots: false,
        arrows: true,
        autoplay: true,
        autoplaySpeed: 3000,
        adaptiveHeight: true,
        infinite: true,
        draggable: true,
        slidesToShow: 3,
        slidesToScroll: 1,
        waitForAnimate: false,
        swipe: false,
        pauseOnHover: true,
        responsive: [
            {
              breakpoint: 991,
              settings: {
                slidesToShow: 2,
              }
            },
            {
              breakpoint: 767,
              settings: {
                slidesToShow: 1,
              }
            }
        ]
    });
});


function hideBanner() {
  document.querySelector('.banner-overlay').style.display = 'none';
}

