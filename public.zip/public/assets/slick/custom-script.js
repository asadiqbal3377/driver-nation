jQuery(document).ready(function($) {
    $(".jcodex-home-page-review-slide-track").slick({
        dots: false,
        arrows: false,
        autoplay: true,
        autoplaySpeed: 3000,
        // speed: 5000,
        adaptiveHeight: true,
        infinite: true,
        draggable: false,
        slidesToShow: 3,
        slidesToScroll: 1,
        // cssEase: 'flip',
        waitForAnimate: false,
        swipe: false,
        pauseOnHover: true,
        responsive: [
            {
              breakpoint: 991,
              settings: {
                slidesToShow: 2,
              }
            },
            {
              breakpoint: 767,
              settings: {
                slidesToShow: 1,
              }
            }
          ] 
    });
});


jQuery(document).ready(function($) {
  // console.log('Hello');
  let sidebar = $(".jcodex-plugin-documentation-right-sidebar-secondary-div");
  let contentHeight = sidebar.height();
  let sidebarTop = sidebar.offset().top + $(window).scrollTop();

  $(window).scroll(function() {
      let scrollTop = $(window).scrollTop();
      let viewportHeight = $(window).height();

      if (scrollTop >= sidebarTop && scrollTop <= contentHeight - viewportHeight + sidebarTop) {
          sidebar.css({
              position: "relative",
              top: "0"
          });
      } else if (scrollTop > contentHeight - viewportHeight + sidebarTop && contentHeight > viewportHeight) {
          sidebar.css({
              position: "sticky",
              top: `${-contentHeight + viewportHeight}px`
          });
      } else if (contentHeight < viewportHeight) {
          sidebar.css({
              position: "sticky",
              top: "50px"
          });
      } else {
          sidebar.css({
              position: "",
              top: ""
          });
      }
  });
});


// Accordian New JS
jQuery(document).ready(function($) {
  // Check if there's an active-post
  if ($('.active-post').length > 0) {
    console.log('.active-post');
    // $('.active-post').closest('.acc_panel'){
      $('.active-post').closest('.acc_panel').siblings('.acc_ctrl').addClass('active');
      $('.active-post').closest('.acc_panel').css('display', 'block');
    // }
  }
  // Accordion click event handler
  $('.acc_ctrl').on('click', function(e) {
    e.preventDefault();
    if ($(this).hasClass('active')) {
      $(this).removeClass('active');
      $(this).next()
        .stop()
        .slideUp(300);
    } else {
      $(this).addClass('active');
      $(this).next()
        .stop()
        .slideDown(300);
    }
  });
});


// Texonomy-Docs page side Accordian 

jQuery(document).ready(function($) {
  // Check if there's an active-post
  if ($('.active-post').length) {
    // Find the closest '.acc_panel' to the '.active-post'
    var closestAccPanel = $('.active-post').closest('.texonomy_doc_acc_panel');
    
    // Find the button within the acc_panel and add the 'active' class
    closestAccPanel.find('.texonomy_doc_acc_ctrl').addClass('active');
  }

  // Accordion click event handler
  $('.texonomy_doc_acc_ctrl').on('click', function(e) {
    e.preventDefault();
    var accordionContent = $(this).next();

    if ($(this).hasClass('active')) {
      $(this).removeClass('active');
      accordionContent.stop().slideUp(300);
    } else {
      $(this).addClass('active');
      accordionContent.stop().slideDown(300);
    }
  });
});

