<?php

namespace Database\Seeders;

use App\Models\Blog;
use App\Models\Category;
use App\Models\News;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class CategorySeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {

        $data = [
            [
                'title' => 'Local',
                'slug' => 'local-news',
                'is_active' => true,
                'model_for' => News::class,
                'created_at' => now(),
                'updated_at' => now()
            ],[
                'title' => 'Local',
                'slug' => 'local-blog',
                'is_active' => true,
                'model_for' => Blog::class,
                'created_at' => now(),
                'updated_at' => now()
            ],[
                'title' => 'National',
                'slug' => 'national-news',
                'is_active' => true,
                'model_for' => News::class,
                'created_at' => fake()->dateTime(),
                'updated_at' => fake()->dateTime()
            ],[
                'title' => 'National',
                'slug' => 'national-blogs',
                'is_active' => true,
                'model_for' => Blog::class,
                'created_at' => fake()->dateTime(),
                'updated_at' => fake()->dateTime()
            ],
            [
                'title' => 'Automotive',
                'slug' => 'automotive',
                'is_active' => true,
                'model_for' => Blog::class,
                'created_at' => fake()->dateTime(),
                'updated_at' => fake()->dateTime()
            ],
            [
                'title' => 'Auto Shop',
                'slug' => 'auto-shop',
                'is_active' => true,
                'model_for' => Blog::class,
                'created_at' => fake()->dateTime(),
                'updated_at' => fake()->dateTime()
            ]
        ];

        array_map(function ($item) {
            Category::create($item);
        }, $data);

    }
}
