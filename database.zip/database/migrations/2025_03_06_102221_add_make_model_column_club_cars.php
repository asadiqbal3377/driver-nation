<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('club_cars', function (Blueprint $table) {
            $table->longText('body_type')->nullable()->after('engine_type');
            $table->string('make')->nullable()->after('body_type');
            $table->longText('model')->nullable()->after('make');
            $table->longText('engin_capacity')->nullable()->after('model');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('club_cars', function (Blueprint $table) {
            $table->dropColumn('body_type');
            $table->dropColumn('make');
            $table->dropColumn('model');
            $table->dropColumn('engin_capacity');
        });
    }
};
