<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('club_cars', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained('users');
            $table->foreignId('club_id')->constrained('clubs');
            $table->string('title');
            $table->enum('status',['publish','draft','disable'])->default('publish');
            $table->text('images')->nullable();
            $table->string('video')->nullable();
            $table->string('facebook')->nullable();
            $table->string('tiktok')->nullable();
            $table->string('instagram')->nullable();
            $table->string('linkedin')->nullable();
            $table->string('odometer');
            $table->string('engine_type');
            $table->string('horse_power');
            $table->string('transmission');
            $table->year('year');
            $table->string('exterior_color');
            $table->string('exhaust');
            $table->string('wheels');
            $table->string('business_directory')->nullable();
            $table->string('engin')->nullable();
            $table->string('business_tags')->nullable();
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('club_cars');
    }
};
