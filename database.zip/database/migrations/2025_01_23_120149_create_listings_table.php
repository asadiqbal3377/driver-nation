<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('listings', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained('users');
            $table->string('title');
            $table->text('description');
            $table->string('slug');
            $table->double('rating', 5,2)->default(0);
            $table->string('status')->default('active');
            $table->string('start_time');
            $table->string('end_time');
            $table->string('phone');
            $table->string('website');
            $table->string('location');
            $table->string('city')->nullable();
            $table->text('images')->nullable();
            $table->string('videos')->nullable();
            $table->string('qr')->nullable();
            $table->string('logo')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('listings');
    }
};
