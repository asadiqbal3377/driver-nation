<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('events', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained('users');
            $table->string('title');
            $table->text('event_details')->nullable();
            $table->string('slug')->nullable();
            $table->string('user_fb_id')->nullable();
            $table->string('event_id')->nullable();

            $table->date('start_date')->nullable();
            $table->time('start_time')->nullable();
            $table->string('start_timezone')->nullable();

            $table->date('end_date')->nullable();
            $table->time('end_time')->nullable();
            $table->string('end_timezone')->nullable();
            $table->string('market')->nullable();
            $table->string('location')->nullable();
            $table->string('city')->nullable();
            $table->string('free_paid')->default('free');

            $table->text('event_json')->nullable();

            $table->text('images')->nullable()->comment('total 5 attachments allowed either images or videos');
            $table->text('videos')->nullable()->comment('total 5 attachments allowed either images or videos');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('events');
    }
};
